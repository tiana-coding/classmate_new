import { Component } from '@angular/core';

@Component({
  selector: 'app-agenda',
  standalone: true,
  imports: [],
  templateUrl: './agenda.html',
  styleUrl: './agenda.css'
})
export class AgendaComponent {

}
